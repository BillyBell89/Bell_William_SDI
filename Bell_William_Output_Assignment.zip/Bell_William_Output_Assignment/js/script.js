/**
 * Created by BB on 10/1/15.
 */
//William Bell
    //SDI Section 1

//create variables here (don't forget to use Camel Case)

    //assign string variables
var favSong = "Ophelia";
var favBand = "The Band";
    //assign boolean vars
var bandStatus = false;
    //assign number vars
var bandFormed = 1968
var birthYear = 1989;

//create alerts using variables, concatenate with strings

    alert("My name is William Bell and I want to tell you about my favorite band, " + favBand + ".");
    alert("My favorite song by " + favBand + " is " + favSong + ".");
    alert("The band formed in " + bandFormed + ", " + (birthYear-bandFormed)+ "years before I was born.");
    alert("You may be wondering if the band is still together.")

//use an if else statement and hope the professor doesn't mind

    if (bandStatus==false){alert("Unfortunately they are not.")}
    else {alert("Yes they are!")};


































